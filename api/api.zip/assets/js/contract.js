new Vue({
    el: '#contract',
    vuetify: new Vuetify(),
    //DADOS
    data: () => ({

    }),
    mounted() {

    },
    created() {

    },
    method: {
        
    }
}) 
